import{d as t,bu as r}from"./index-BUuZZGdr.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
